import React from "react";

<div class="header"> 



  <meta name="viewport" content="width=device-width, initial-scale=1"></meta>

  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"></link>

  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Karma"></link>




  <link rel="shortcut icon" href=""></link>

  <link href="https://fonts.googleapis.com/css2?family=Krona+One&display=swap" rel="stylesheet"></link>

  <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:ital,wght@0,300;0,400;1,300&display=swap" rel="stylesheet"></link>

  <script src="https://kit.fontawesome.com/85dbc41dda.js" crossorigin="anonymous"></script>

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

  </div>